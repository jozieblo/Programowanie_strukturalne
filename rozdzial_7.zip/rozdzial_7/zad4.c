#include <stdio.h>
#include <stdlib.h>

int main(){

    char znak;
    int sw = 0;
    while((znak = getchar()) != '#'){
        if(znak == '.'){
                sw++;
        }
        else if(znak == '!'){
            sw++;
        }
    }
    printf("Liczba zamian: %d\n", sw);
    return 0;
}
