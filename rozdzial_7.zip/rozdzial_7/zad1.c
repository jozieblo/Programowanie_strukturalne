
#include <stdio.h>
#include <stdlib.h>

int main(){

    char znak;
    char tabs[100];
    int tab[100] = {0};
    int i = 1;
    while((znak = getchar()) != '#'){
        int j;
        for(j = 0; j < i; j++){
            if(tabs[j] == znak){
                tab[j]++;
                break;
            }
        }
        if(j == i){
            tabs[i - 1] = znak;
            tab[i - 1]++;
            i++;
        }
    }
    for(int z = 0; z < i - 1; z++){
        if(tabs[z] == '\n') printf("Znak: '\\n', liczba wystapien: %d\n", tab[z]);
        else printf("Znak: '%c', liczba wystapien: %d\n",tabs[z], tab[z]);
    }
    return 0;
}
