#include <stdio.h>
#include <stdlib.h>

int main(){

    int liczba, p = 0, n = 0, liczbaP = 0, liczbaNP = 0;
    while(free){
        scanf("%d", &liczba);
    if(liczba == 0) break;
        switch (liczba){
            case 1:
                n += liczba;
                liczbaNP++;
                break;
            case 2:
                p += liczba;
                liczbaP++;
                break;
            case 3:
                n += liczba;
                liczbaNP++;
                break;
            case 4:
                p += liczba;
                liczbaP++;
                break;
            case 5:
                n += liczba;
                liczbaNP++;
                break;
            case 6:
                p += liczba;
                liczbaP++;
                break;
            case 7:
                n += liczba;
                liczbaNP++;
                break;
            case 8:
                p += liczba;
                liczbaP++;
                break;

            case 9:
                n += liczba;
                liczbaNP++;
                break;
        }
    }
    float sredniaP = p / liczbaP;
    float sredniaNP = n / liczbaNP;
    printf("Parzyste liczby: %d, srednia tych liczb to: %g\n", liczbaP, sredniaP);
    printf("Nieparzyste liczby: %d, srednia tych liczb tp : %g", liczbaNP, sredniaNP);
    return 0;
}
