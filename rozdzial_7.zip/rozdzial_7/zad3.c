  #include <stdio.h>
#include <stdlib.h>

int main(){

    int liczba, p = 0, n = 0, liczbaP = 0, liczbaNP = 0;
    while(scanf(" %d", &liczba) != 0){
        if(liczba == 0) break;
        if(liczba % 2 == 0){
            p += liczba;
            liczbaP++;
        }
        else{
            n += liczba;
            liczbaNP++;
        }
    }
    float sredniaP = p / liczbaP;
    float sredniaNP = n / liczbaNP;
    printf("Parzyste: %d, srednia: %g\n", liczbaP, sredniaP);
    printf("Nieparzyste: %d, srednia: %g", liczbaNP, sredniaNP);
    return 0;
}
