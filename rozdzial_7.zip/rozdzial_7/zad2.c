#include <stdio.h>
#include <stdlib.h>

int main(){
    char znak;
    char tabs[100];
    int i = 0;
    while((znak = getchar()) != '#'){
        if(znak == '\n') {tabs[i] = '\n';}
        else {tabs[i] = znak;}

        i++;
    }
    for(int z = 1; z <= i; z++){
        printf("'%c'-%d, ", tabs[z - 1], (int)tabs[z - 1]);
        if(z % 8 == 0) printf("\n");
    }
    return 0;
}
