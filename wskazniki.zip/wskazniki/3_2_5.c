#include <stdio.h>
#include <stdlib.h>
int funkcja1 (int,int);
int main()
{
    int x=5,y=10;
    int *wskx,*wsky;
    wskx=&x,wsky=&y;
    funkcja1(*wskx,*wsky);

    return 0;
}
int funkcja1 (int wskx, int wsky)
{
   int suma=0;
   suma=wskx+wsky;

    printf("Suma wynosi:  %d\n",suma);

    return 0;
}
