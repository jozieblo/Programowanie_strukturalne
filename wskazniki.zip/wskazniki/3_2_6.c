#include <stdio.h>
#include <stdlib.h>
int funkcja1(int,int);
int main()
{
    int n=5,w=0;
    int *wskn,*wskw;
    wskn=&n,wskw=&w;
    funkcja1(n,*wskw);
    return 0;
}
int funkcja1(int n, int wskw)
{
    int x=0;
    x=n;
    wskw=x;
    printf("Zmienna n wynosi: %d\n", n);
    printf("Zmienna w wynosi: %d\n", wskw);
}
