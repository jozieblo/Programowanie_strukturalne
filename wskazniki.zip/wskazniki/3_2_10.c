#include <stdio.h>
#include <stdlib.h>

int main(){

    printf("%p", funkcja());
    return 0;
}

int funkcja()
{
    double x;
    double *wskaznik;
    wskaznik = (double*) malloc(x * sizeof(*wskaznik));

    return wskaznik;
}
