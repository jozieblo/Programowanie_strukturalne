#include <stdio.h>
#include <stdlib.h>
int funkcja1 (int ,int );
int main()
{
    int x=10,y=5;
    int*wskx,*wsky;
    wskx=&x,wsky=&y;
    funkcja1(*wskx,*wsky);

    return 0;
}
int funkcja1 (int wskx, int wsky)
{
    int z=0,q=0;
    if(wskx>wsky)
    {
         z=wskx;
         q=wsky;
        wsky=z;
        wskx=q;
        printf("Od teraz x wynosi:  %d\n",wskx);
        printf("Od teraz y wynosi:  %d\n",wsky);
    }
    else
    {
        printf("Nic sie nie zmienilo!");
    }
    return 0;
}
