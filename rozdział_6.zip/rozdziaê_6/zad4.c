#include <stdio.h>
#include <stdlib.h>

int main(){

    char a;
    printf("Podaj duza litere: ");
    scanf("%c", &a);
    int h = (int)a - 65;
    for(int i = 65; i <= (int)a; i++){
        for(int b = 0; b < h; b++){
            printf(" ");
        }
        int c;
        for(c = 65;c <= (int)a - h; c++){
            printf("%c", c);
        }
        h--;
        c -= 2;
        for(int j = 65; j <  i; j++){
            printf("%c", c);
            c -= 1;
        }
        printf("\n");
    }
    return 0;
}
