#include <stdio.h>
#include <stdlib.h>
int main()
{
    char tab[26];
    int i=0,j=0;
    char z='a';
    while (z<='z')
    {
        tab[i]=z;
        i++;
        z++;
    }
    for(j=0;j<26;j++)
    {

        printf("%c\n",tab[j]);
    }
    return 0;
}
