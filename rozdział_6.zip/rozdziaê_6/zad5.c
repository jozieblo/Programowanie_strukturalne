#include <stdlib.h>
#include <stdio.h>
int main ()
{
    int mini,maksi;
    printf("Podaj liczbe najmniejsza ktora ma byc wyswietlana w tabeli: ");
    scanf("%d", &mini);
     printf("Podaj liczbe najwieksza ktora ma byc wyswietlana w tabeli: ");
    scanf("%d", &maksi);
    for(int i=mini;i<=maksi;i++)
    {
        printf("%d : %d : %d\n", i, i * i, i * i * i);
    }
    return 0;
}

