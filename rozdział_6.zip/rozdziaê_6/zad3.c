#include <stdio.h>
#include <stdlib.h>

int main()
{
  char z ='F';
  for (int i=0;i<6;i++)
  {
      for( int j=0;j<=i;j++)
      {
          printf("%c",z);
          z--;
      }
      printf("\n");
      z='F';
  }
  return 0;
}
