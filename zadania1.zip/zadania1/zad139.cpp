#include <iostream>

using namespace std;

int main()
{
    float x,y,wynik;
    int liczba;
    cout << "Oto kalkulator online! Wprowadz 2 liczby: ";
    cin>>x;
    cin>>y;
    cout<<"Teraz wybierz operacje ktora chcesz wykonac na tych liczbach"<<endl;
    cout<<"1-Dodawanie"<<endl;
    cout<<"2-Odejmowanie"<<endl;
    cout<<"3-Mnozenie"<<endl;
    cout<<"4-Dzielenie"<<endl<<endl;
    cin>>liczba;
    switch(liczba)
    {
        case 1:
        wynik=x+y;
        cout<<wynik<<endl;
        break;
        case 2:
        wynik=x-y;
        cout<<wynik<<endl;
        break;
        case 3:
        wynik=x*y;
        cout<<wynik<<endl;
        break;
        case 4:
        wynik=x/y;
        cout<<wynik<<endl;
        break;
        default:
            cout<<"Nieprawidlowa liczba!";
    }

    return 0;
}
