#include <iostream>
#include <math.h>
using namespace std;

int main()
{
    float a,b,c,delta,x1,x2,x0;
    cout << "Wprowadz a,b,c: ";
    cin>>a;
    cin>>b;
    cin>>c;
    delta=(b*b)-4*a*c;
    if(delta>0)
    {
        x1=(-b-sqrt(delta))/(2*a);
        x2=(-b+sqrt(delta))/(2*a);
        cout<<"Miejsca zerowe to: "<<x1<<" "<<x2;
    }
     else if(delta==0)
    {
        x0=-b/(2*a);
        cout<<"Miejsce zerowe to: "<<x1;
    }
    else
    {
        cout<<"Delta ujemna! Brak miejsc zerowych";
    }

    return 0;
}
