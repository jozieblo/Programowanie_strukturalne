#include <iostream>

using namespace std;

int main()
{
    int i,n,suma;
    cout << "Wprowadz liczbe nieujemna n: ";
    cin>>n;
    if(n<0)
    {
        cout<<"Liczba nie jest nieujmna!";
        return 0;
    }
    else
    {
        suma=0;
        for(i=0;i<=n;i++)
        {
            suma=suma+(i*i);
        }
    }
    cout<<suma;
    return 0;
}
