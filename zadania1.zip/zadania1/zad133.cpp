#include <iostream>
using namespace std;
int main()
{
    int x,y,z;
    cout << "Wprowadz 3 liczby calkowite: ";
    cin>>x;
    cin>>y;
    cin>>z;
    if(x>y && x>z)
    {
        cout<<"Najwieksza liczba jest: "<<x<<endl;
    }
    else if(y>z && y>x)
    {
        cout<<"Najwieksza liczba jest: "<<y<<endl;
    }
    else if(z>y && z>x)
    {
        cout<<"Najwieksza liczba jest: "<<z<<endl;
    }
    else
    {
        cout<<"Miedzy poszczegolnymi liczbami zachodzi rownosc!"<<endl;
    }
    return 0;
}
