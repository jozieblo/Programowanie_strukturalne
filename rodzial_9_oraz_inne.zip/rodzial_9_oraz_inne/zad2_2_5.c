#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int fun(int);
int main()
{
    int x;
    do
    {
        printf("Wprowadz liczbe nieujemna calkowita: ");
        scanf("%d", &x);
    }while(x<0);
    fun(x);

    return 0;
}
int fun(int x)
{
    int wynik=pow(2,x);
    printf("2 do potegi %d to %d",x,wynik);
    return wynik;
}
