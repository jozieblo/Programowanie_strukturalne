#include <stdio.h>
#include <stdlib.h>
int mini (double,double);
int main()
{
    double x,y;
    printf("Wprowadz 1 liczbe: ");
    scanf("%lf",&x);
     printf("Wprowadz 2 liczby: ");
    scanf("%lf",&y);
    mini(x,y);
    return 0;
}
int mini (double x, double y)
{
    if(x<y)
    {
        printf("Mniejsza liczba jest %lf",x);

    }
    else if(x>y)
    {
        printf("Mniejsza liczba jest %lf",y);

    }
    else
    {
        printf("Liczby sa sobie rowne!");
    }
    return 0;
}
