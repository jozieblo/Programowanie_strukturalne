#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int fun2(int, int);
int main()
{
    int n,m;
    do
    {
        printf("Wprowadz liczbe nieujemna calkowita: ");
        scanf("%d", &n);
        printf("Wprowadz liczbe nieujemna calkowita: ");
        scanf("%d", &m);
    }while(n<0 && m<0);
    fun2(n,m);

    return 0;
}
int fun2(int n, int m)
{
    int wynik=0;
    if (n!=0 || m!=0)
    {
        wynik = pow(n,m);
        printf("%d do potegi %d to %d",n,m,wynik);

    }
    else
    {
        printf("Conajmniej jedna liczba nie jest rozna od zera!");

    }
    return wynik;
}
