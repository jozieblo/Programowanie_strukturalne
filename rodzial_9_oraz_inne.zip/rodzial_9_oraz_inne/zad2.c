#include <stdlib.h>
#include <stdio.h>
int rzad_zn (char,int,int);
int main()
{
    char znak="$";
    int i,j;
    printf("Wprowadz 1 liczbe: ");
    scanf("%d",&i);
     printf("Wprowadz 2 liczbe: ");
    scanf("%d",&j);
    rzad_zn(znak,i,j);
    return 0;
}
int rzad_zn (char znak,int i, int j)
{
    for (int p=i;p<=j;p++)
    {
        printf(" %c", znak);
    }
    return 0;
}
