#include <stdio.h>
#include <stdlib.h>
int funk3 (int);
int main()
{
    int n;
    do{
        printf("Wprowadz nieujemna liczbe calkowita: ");
    scanf("%d", &n);
    }while(n<0);
    funk3(n);
    return 0;

}
int funk3 (int n)
{
    int i, an=0;
    int tab[n];
    tab[0]=1;
    for(i=1;i<=n;i++)
    {
        tab[i]=2*tab[i-1]+5;

    }
    printf("a%d",n);
    printf(" wynosi: %d ",tab[n]);
    return 0;
}
