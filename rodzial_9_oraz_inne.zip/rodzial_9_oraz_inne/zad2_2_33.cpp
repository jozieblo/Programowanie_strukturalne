#include <iostream>
using namespace std;
int funk (unsigned int,unsigned int,unsigned int,unsigned int,unsigned int);

int main()
{
     unsigned int a,b,c,d,e;
     cout<<"Wprowadz pierwsza liczbe: ";
     cin>>a;
     cout<<"Wprowadz druga liczbe: ";
     cin>>b;
     cout<<"Wprowadz trzecia liczbe: ";
     cin>>c;
     cout<<"Wprowadz czwarta liczbe: ";
     cin>>d;
     cout<<"Wprowadz piata liczbe: ";
     cin>>e;
     funk(a,b,c,d,e);
    return 0;
}
int funk (unsigned int a ,unsigned int b,unsigned int c,unsigned int d ,unsigned int e)
{
    unsigned int suma=0;
    suma=a+b+c+d+e;
    cout<<"Suma dwoch liczb wynosi: "<<a+b<<endl;
    cout<<"Suma  trzech liczb wynosi: "<<a+b+c<<endl;
    cout<<"Suma czterech liczb wynosi: "<<a+b+c+d<<endl;
    cout<<"Suma tych wszystkich liczb wynosi: "<<suma<<endl;
    return suma;
}
